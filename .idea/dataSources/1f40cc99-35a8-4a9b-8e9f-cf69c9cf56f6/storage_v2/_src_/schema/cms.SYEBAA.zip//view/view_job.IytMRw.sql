CREATE VIEW view_job AS
  SELECT
    `a`.`id`           AS `id`,
    `a`.`title`        AS `title`,
    `a`.`address_id`   AS `address_id`,
    `a`.`jobnum`       AS `jobnum`,
    `a`.`treatment`    AS `treatment`,
    `a`.`describes`    AS `describes`,
    `a`.`requires`     AS `requires`,
    `a`.`positiontype` AS `positiontype`,
    `a`.`inputdate`    AS `inputdate`,
    `a`.`isenabled`    AS `isenabled`,
    `a`.`htmlurl`      AS `htmlurl`,
    `b`.`address`      AS `address`,
    `b`.`pid`          AS `pid`,
    `c`.`address`      AS `proname`
  FROM ((`cms`.`jobs` `a`
    JOIN `cms`.`address` `b` ON ((`a`.`address_id` = `b`.`id`))) JOIN `cms`.`address` `c` ON ((`b`.`pid` = `c`.`id`)));

